/**
 * 
 */
package com.bfly.domain;

/**
 * @author ksg
 *
 */
public class Domain {
protected void logMe()
{
	System.out.println("This is me!!!" + this.getClass().getSimpleName());
}
}
