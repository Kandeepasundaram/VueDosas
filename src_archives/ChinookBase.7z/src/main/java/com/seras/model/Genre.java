package com.seras.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the GENRE database table.
 * 
 */
@Entity
@Table(name="GENRE")
@NamedQuery(name="Genre.findAll", query="SELECT g FROM Genre g")
public class Genre extends com.seras.core.SerasDBModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(unique=true, nullable=false, precision=22)
	private long genreid;

	@Column(length=120)
	private String name;

	public Genre() {
	}

	public long getGenreid() {
		return this.genreid;
	}

	public void setGenreid(long genreid) {
		this.genreid = genreid;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}