package com.seras.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the ALBUM database table.
 * 
 */
@Entity
@Table(name="ALBUM")
@NamedQuery(name="Album.findAll", query="SELECT a FROM Album a")
public class Album extends com.seras.core.SerasDBModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(unique=true, nullable=false, precision=22)
	private long albumid;

	@Column(nullable=false, length=160)
	private String title;

	//uni-directional many-to-one association to Artist
	@ManyToOne
	@JoinColumn(name="ARTISTID", nullable=false)
	private Artist artist;

	public Album() {
	}

	public long getAlbumid() {
		return this.albumid;
	}

	public void setAlbumid(long albumid) {
		this.albumid = albumid;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Artist getArtist() {
		return this.artist;
	}

	public void setArtist(Artist artist) {
		this.artist = artist;
	}

}