package com.seras.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the ARTIST database table.
 * 
 */
@Entity
@Table(name="ARTIST")
@NamedQuery(name="Artist.findAll", query="SELECT a FROM Artist a")
public class Artist extends com.seras.core.SerasDBModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(unique=true, nullable=false, precision=22)
	private long artistid;

	@Column(length=120)
	private String name;

	public Artist() {
	}

	public long getArtistid() {
		return this.artistid;
	}

	public void setArtistid(long artistid) {
		this.artistid = artistid;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}