package com.seras.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the TRACK database table.
 * 
 */
@Entity
@Table(name="TRACK")
@NamedQuery(name="Track.findAll", query="SELECT t FROM Track t")
public class Track extends com.seras.core.SerasDBModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(unique=true, nullable=false, precision=22)
	private long trackid;

	@Column(precision=22)
	private BigDecimal bytes;

	@Column(length=220)
	private String composer;

	@Column(nullable=false, precision=22)
	private BigDecimal milliseconds;

	@Column(nullable=false, length=200)
	private String name;

	@Column(nullable=false, precision=10, scale=2)
	private BigDecimal unitprice;

	//uni-directional many-to-one association to Album
	@ManyToOne
	@JoinColumn(name="ALBUMID")
	private Album album;

	//uni-directional many-to-one association to Genre
	@ManyToOne
	@JoinColumn(name="GENREID")
	private Genre genre;

	//uni-directional many-to-one association to Mediatype
	@ManyToOne
	@JoinColumn(name="MEDIATYPEID", nullable=false)
	private Mediatype mediatype;

	//uni-directional many-to-many association to Playlist
	@ManyToMany
	@JoinTable(
		name="PLAYLISTTRACK"
		, joinColumns={
			@JoinColumn(name="TRACKID", nullable=false)
			}
		, inverseJoinColumns={
			@JoinColumn(name="PLAYLISTID", nullable=false)
			}
		)
	private List<Playlist> playlists;

	public Track() {
	}

	public long getTrackid() {
		return this.trackid;
	}

	public void setTrackid(long trackid) {
		this.trackid = trackid;
	}

	public BigDecimal getBytes() {
		return this.bytes;
	}

	public void setBytes(BigDecimal bytes) {
		this.bytes = bytes;
	}

	public String getComposer() {
		return this.composer;
	}

	public void setComposer(String composer) {
		this.composer = composer;
	}

	public BigDecimal getMilliseconds() {
		return this.milliseconds;
	}

	public void setMilliseconds(BigDecimal milliseconds) {
		this.milliseconds = milliseconds;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigDecimal getUnitprice() {
		return this.unitprice;
	}

	public void setUnitprice(BigDecimal unitprice) {
		this.unitprice = unitprice;
	}

	public Album getAlbum() {
		return this.album;
	}

	public void setAlbum(Album album) {
		this.album = album;
	}

	public Genre getGenre() {
		return this.genre;
	}

	public void setGenre(Genre genre) {
		this.genre = genre;
	}

	public Mediatype getMediatype() {
		return this.mediatype;
	}

	public void setMediatype(Mediatype mediatype) {
		this.mediatype = mediatype;
	}

	public List<Playlist> getPlaylists() {
		return this.playlists;
	}

	public void setPlaylists(List<Playlist> playlists) {
		this.playlists = playlists;
	}

}