package com.seras.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the MEDIATYPE database table.
 * 
 */
@Entity
@Table(name="MEDIATYPE")
@NamedQuery(name="Mediatype.findAll", query="SELECT m FROM Mediatype m")
public class Mediatype extends com.seras.core.SerasDBModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(unique=true, nullable=false, precision=22)
	private long mediatypeid;

	@Column(length=120)
	private String name;

	public Mediatype() {
	}

	public long getMediatypeid() {
		return this.mediatypeid;
	}

	public void setMediatypeid(long mediatypeid) {
		this.mediatypeid = mediatypeid;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}