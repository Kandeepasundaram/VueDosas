package com.seras.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the INVOICE database table.
 * 
 */
@Entity
@Table(name="INVOICE")
@NamedQuery(name="Invoice.findAll", query="SELECT i FROM Invoice i")
public class Invoice extends com.seras.core.SerasDBModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(unique=true, nullable=false, precision=22)
	private long invoiceid;

	@Column(length=70)
	private String billingaddress;

	@Column(length=40)
	private String billingcity;

	@Column(length=40)
	private String billingcountry;

	@Column(length=10)
	private String billingpostalcode;

	@Column(length=40)
	private String billingstate;

	@Temporal(TemporalType.DATE)
	@Column(nullable=false)
	private Date invoicedate;

	@Column(nullable=false, precision=10, scale=2)
	private BigDecimal total;

	//uni-directional many-to-one association to Customer
	@ManyToOne
	@JoinColumn(name="CUSTOMERID", nullable=false)
	private Customer customer;

	public Invoice() {
	}

	public long getInvoiceid() {
		return this.invoiceid;
	}

	public void setInvoiceid(long invoiceid) {
		this.invoiceid = invoiceid;
	}

	public String getBillingaddress() {
		return this.billingaddress;
	}

	public void setBillingaddress(String billingaddress) {
		this.billingaddress = billingaddress;
	}

	public String getBillingcity() {
		return this.billingcity;
	}

	public void setBillingcity(String billingcity) {
		this.billingcity = billingcity;
	}

	public String getBillingcountry() {
		return this.billingcountry;
	}

	public void setBillingcountry(String billingcountry) {
		this.billingcountry = billingcountry;
	}

	public String getBillingpostalcode() {
		return this.billingpostalcode;
	}

	public void setBillingpostalcode(String billingpostalcode) {
		this.billingpostalcode = billingpostalcode;
	}

	public String getBillingstate() {
		return this.billingstate;
	}

	public void setBillingstate(String billingstate) {
		this.billingstate = billingstate;
	}

	public Date getInvoicedate() {
		return this.invoicedate;
	}

	public void setInvoicedate(Date invoicedate) {
		this.invoicedate = invoicedate;
	}

	public BigDecimal getTotal() {
		return this.total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public Customer getCustomer() {
		return this.customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

}