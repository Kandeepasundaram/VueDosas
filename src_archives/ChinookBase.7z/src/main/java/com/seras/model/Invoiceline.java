package com.seras.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the INVOICELINE database table.
 * 
 */
@Entity
@Table(name="INVOICELINE")
@NamedQuery(name="Invoiceline.findAll", query="SELECT i FROM Invoiceline i")
public class Invoiceline extends com.seras.core.SerasDBModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(unique=true, nullable=false, precision=22)
	private long invoicelineid;

	@Column(nullable=false, precision=22)
	private BigDecimal quantity;

	@Column(nullable=false, precision=10, scale=2)
	private BigDecimal unitprice;

	//uni-directional many-to-one association to Invoice
	@ManyToOne
	@JoinColumn(name="INVOICEID", nullable=false)
	private Invoice invoice;

	//uni-directional many-to-one association to Track
	@ManyToOne
	@JoinColumn(name="TRACKID", nullable=false)
	private Track track;

	public Invoiceline() {
	}

	public long getInvoicelineid() {
		return this.invoicelineid;
	}

	public void setInvoicelineid(long invoicelineid) {
		this.invoicelineid = invoicelineid;
	}

	public BigDecimal getQuantity() {
		return this.quantity;
	}

	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getUnitprice() {
		return this.unitprice;
	}

	public void setUnitprice(BigDecimal unitprice) {
		this.unitprice = unitprice;
	}

	public Invoice getInvoice() {
		return this.invoice;
	}

	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}

	public Track getTrack() {
		return this.track;
	}

	public void setTrack(Track track) {
		this.track = track;
	}

}