package com.seras.model.projections;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.rest.core.config.Projection;

import com.seras.model.Album;
import com.seras.model.Artist;
import com.seras.model.Playlist;
import com.seras.model.Track;

@Projection(name = "trackpro", types =
{ Track.class, Album.class, Artist.class })
public interface TrackProjection
{
    String getName();

    @Value("#{target.album}")
    List<Album> getCustom();

    @Value("#{target.playlists}")
    List<Playlist> getPlaylists();

}
