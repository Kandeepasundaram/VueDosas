package com.seras.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the PLAYLIST database table.
 * 
 */
@Entity
@Table(name="PLAYLIST")
@NamedQuery(name="Playlist.findAll", query="SELECT p FROM Playlist p")
public class Playlist extends com.seras.core.SerasDBModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(unique=true, nullable=false, precision=22)
	private long playlistid;

	@Column(length=120)
	private String name;

	public Playlist() {
	}

	public long getPlaylistid() {
		return this.playlistid;
	}

	public void setPlaylistid(long playlistid) {
		this.playlistid = playlistid;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}