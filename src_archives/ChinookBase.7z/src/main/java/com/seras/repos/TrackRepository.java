/**
 * 
 */
package com.seras.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seras.model.Track;

/**
 * @author ksg
 *
 */
public interface TrackRepository extends JpaRepository<Track, Long>
{

}
