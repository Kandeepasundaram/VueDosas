/**
 * 
 */
/*
 * package com.seras.repos;
 * 
 * import org.springframework.data.jpa.repository.JpaRepository;
 * 
 * import com.seras.model.Artist;
 * 
 *//**
   * @author ksg
   *
   *//*
     * public interface ArtistRepository extends JpaRepository<Artist, Long> {
     * 
     * }
     */