/**
 * 
 */
package com.seras.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seras.model.Invoiceline;

/**
 * @author ksg
 *
 */
public interface InvoiceLineRepository extends JpaRepository<Invoiceline, Long>
{

}
