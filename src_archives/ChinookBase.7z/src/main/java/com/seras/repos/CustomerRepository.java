/**
 * 
 */
package com.seras.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seras.model.Customer;

/**
 * @author ksg
 *
 */
public interface CustomerRepository extends JpaRepository<Customer, Long>
{

}
