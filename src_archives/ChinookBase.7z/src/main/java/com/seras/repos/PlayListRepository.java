/**
 * 
 */
/*
 * package com.seras.repos;
 * 
 * import org.springframework.data.jpa.repository.JpaRepository;
 * 
 * import com.seras.model.Playlist;
 * 
 *//**
   * @author ksg
   *
   *//*
     * public interface PlayListRepository extends JpaRepository<Playlist, Long> {
     * 
     * }
     */