/**
 * 
 */
package com.seras.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seras.model.Employee;

/**
 * @author ksg
 *
 */
public interface EmployeeRepository extends JpaRepository<Employee, Long>
{

}
