/**
 * 
 */
package com.seras.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seras.model.Genre;

/**
 * @author ksg
 *
 */
public interface GenreRepository extends JpaRepository<Genre, Long>
{

}
