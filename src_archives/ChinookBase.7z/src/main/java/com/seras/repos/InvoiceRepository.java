/**
 * 
 */
package com.seras.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seras.model.Invoice;

/**
 * @author ksg
 *
 */
public interface InvoiceRepository extends JpaRepository<Invoice, Long>
{

}
