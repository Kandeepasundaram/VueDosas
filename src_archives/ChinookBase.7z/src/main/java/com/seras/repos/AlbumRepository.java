/**
 * 
 */
package com.seras.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seras.model.Album;

/**
 * @author ksg
 *
 */
public interface AlbumRepository extends JpaRepository<Album, Long>
{

}
