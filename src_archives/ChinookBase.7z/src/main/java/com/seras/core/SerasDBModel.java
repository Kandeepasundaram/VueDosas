/**
 * 
 */
package com.seras.core;

/**
 * @author ksg
 *
 */
public class SerasDBModel
{

    /**
     * 
     */
    public SerasDBModel()
    {
	// TODO Auto-generated constructor stub
    }

}
